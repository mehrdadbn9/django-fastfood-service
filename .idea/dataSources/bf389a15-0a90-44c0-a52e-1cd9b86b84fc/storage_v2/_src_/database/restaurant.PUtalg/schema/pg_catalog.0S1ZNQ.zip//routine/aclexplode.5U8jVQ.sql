create function aclexplode(acl aclitem[], OUT grantor oid, OUT grantee oid, OUT privilege_type text, OUT is_grantable boolean) returns SETOF record
    stable
    strict
    parallel safe
    cost 1
    rows 10
    language internal
as
$$aclexplode$$;

comment on function aclexplode(aclitem[], out oid, out oid, out text, out boolean) is 'convert ACL item array to table, primarily for use by information schema';

alter function aclexplode(aclitem[], out oid, out oid, out text, out boolean) owner to postgres;

