create function aclremove(aclitem[], aclitem) returns aclitem[]
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$aclremove$$;

comment on function aclremove(aclitem[], aclitem) is 'remove ACL item';

alter function aclremove(aclitem[], aclitem) owner to postgres;

