create function acosh(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dacosh$$;

comment on function acosh(double precision) is 'inverse hyperbolic cosine';

alter function acosh(double precision) owner to postgres;

