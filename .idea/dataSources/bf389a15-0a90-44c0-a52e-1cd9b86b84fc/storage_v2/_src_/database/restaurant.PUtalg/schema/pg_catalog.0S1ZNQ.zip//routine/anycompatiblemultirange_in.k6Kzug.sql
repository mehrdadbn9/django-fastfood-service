create function anycompatiblemultirange_in(cstring, oid, integer) returns anycompatiblemultirange
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$anycompatiblemultirange_in$$;

comment on function anycompatiblemultirange_in(cstring, oid, integer) is 'I/O';

alter function anycompatiblemultirange_in(cstring, oid, integer) owner to postgres;

