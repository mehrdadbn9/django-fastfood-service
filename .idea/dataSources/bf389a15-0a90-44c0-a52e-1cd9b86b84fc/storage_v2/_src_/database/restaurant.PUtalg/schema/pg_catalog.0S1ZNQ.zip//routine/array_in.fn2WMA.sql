create function array_in(cstring, oid, integer) returns anyarray
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$array_in$$;

comment on function array_in(cstring, oid, integer) is 'I/O';

alter function array_in(cstring, oid, integer) owner to postgres;

