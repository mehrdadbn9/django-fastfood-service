create function array_recv(internal, oid, integer) returns anyarray
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$array_recv$$;

comment on function array_recv(internal, oid, integer) is 'I/O';

alter function array_recv(internal, oid, integer) owner to postgres;

