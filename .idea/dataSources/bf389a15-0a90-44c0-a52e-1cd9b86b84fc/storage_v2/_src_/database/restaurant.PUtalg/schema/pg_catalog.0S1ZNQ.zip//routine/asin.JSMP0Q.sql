create function asin(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dasin$$;

comment on function asin(double precision) is 'arcsine';

alter function asin(double precision) owner to postgres;

