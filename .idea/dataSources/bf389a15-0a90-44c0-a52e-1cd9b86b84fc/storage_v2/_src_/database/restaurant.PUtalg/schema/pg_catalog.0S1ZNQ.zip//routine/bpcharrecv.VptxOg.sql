create function bpcharrecv(internal, oid, integer) returns character
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$bpcharrecv$$;

comment on function bpcharrecv(internal, oid, integer) is 'I/O';

alter function bpcharrecv(internal, oid, integer) owner to postgres;

