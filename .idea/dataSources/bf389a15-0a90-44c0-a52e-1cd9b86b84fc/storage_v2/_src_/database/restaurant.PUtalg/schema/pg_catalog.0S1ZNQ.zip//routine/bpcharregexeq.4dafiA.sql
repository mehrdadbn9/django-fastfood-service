create function bpcharregexeq(character, text) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$textregexeq$$;

comment on function bpcharregexeq(char, text) is 'implementation of ~ operator';

alter function bpcharregexeq(char, text) owner to postgres;

