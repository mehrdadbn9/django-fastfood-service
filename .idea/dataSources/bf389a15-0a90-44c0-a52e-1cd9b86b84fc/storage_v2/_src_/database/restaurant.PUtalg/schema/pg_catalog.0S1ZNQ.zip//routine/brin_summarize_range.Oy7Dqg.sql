create function brin_summarize_range(regclass, bigint) returns integer
    strict
    cost 1
    language internal
as
$$brin_summarize_range$$;

comment on function brin_summarize_range(regclass, bigint) is 'brin: standalone scan new table pages';

alter function brin_summarize_range(regclass, bigint) owner to postgres;

