create function cbrt(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dcbrt$$;

comment on function cbrt(double precision) is 'cube root';

alter function cbrt(double precision) owner to postgres;

