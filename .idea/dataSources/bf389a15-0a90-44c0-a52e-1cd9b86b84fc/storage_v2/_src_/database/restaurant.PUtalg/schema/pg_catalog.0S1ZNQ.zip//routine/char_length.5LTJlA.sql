create function char_length(text) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$textlen$$;

comment on function char_length(char) is 'character length';

alter function char_length(char) owner to postgres;

