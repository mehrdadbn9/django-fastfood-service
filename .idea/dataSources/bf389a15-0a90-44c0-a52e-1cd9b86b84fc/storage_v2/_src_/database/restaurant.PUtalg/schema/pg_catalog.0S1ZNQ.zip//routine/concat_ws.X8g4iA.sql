create function concat_ws(text, VARIADIC "any") returns text
    stable
    parallel safe
    cost 1
    language internal
as
$$text_concat_ws$$;

comment on function concat_ws(text, "any") is 'concatenate values with separators';

alter function concat_ws(text, "any") owner to postgres;

