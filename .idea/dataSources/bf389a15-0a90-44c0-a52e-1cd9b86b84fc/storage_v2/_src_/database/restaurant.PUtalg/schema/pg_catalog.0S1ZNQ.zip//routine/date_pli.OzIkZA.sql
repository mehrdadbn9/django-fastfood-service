create function date_pli(date, integer) returns date
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$date_pli$$;

comment on function date_pli(date, integer) is 'implementation of + operator';

alter function date_pli(date, integer) owner to postgres;

