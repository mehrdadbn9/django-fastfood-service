create function date_trunc(text, timestamp with time zone) returns timestamp with time zone
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$timestamptz_trunc$$;

comment on function date_trunc(text, interval) is 'truncate interval to specified units';

alter function date_trunc(text, interval) owner to postgres;

