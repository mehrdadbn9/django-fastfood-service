create function dcbrt(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dcbrt$$;

comment on function dcbrt(double precision) is 'implementation of ||/ operator';

alter function dcbrt(double precision) owner to postgres;

