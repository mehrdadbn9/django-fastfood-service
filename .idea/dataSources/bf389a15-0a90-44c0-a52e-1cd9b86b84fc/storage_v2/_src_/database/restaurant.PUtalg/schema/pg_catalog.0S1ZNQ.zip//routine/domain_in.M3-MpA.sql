create function domain_in(cstring, oid, integer) returns "any"
    stable
    parallel safe
    cost 1
    language internal
as
$$domain_in$$;

comment on function domain_in(cstring, oid, integer) is 'I/O';

alter function domain_in(cstring, oid, integer) owner to postgres;

