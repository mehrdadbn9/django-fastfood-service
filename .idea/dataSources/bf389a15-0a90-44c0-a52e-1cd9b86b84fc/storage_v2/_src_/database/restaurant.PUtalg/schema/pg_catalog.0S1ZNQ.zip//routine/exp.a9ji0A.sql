create function exp(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dexp$$;

comment on function exp(double precision) is 'natural exponential (e^x)';

alter function exp(double precision) owner to postgres;

