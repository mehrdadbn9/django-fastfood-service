create function float8(smallint) returns double precision
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$i2tod$$;

comment on function float8(real) is 'convert float4 to float8';

alter function float8(real) owner to postgres;

