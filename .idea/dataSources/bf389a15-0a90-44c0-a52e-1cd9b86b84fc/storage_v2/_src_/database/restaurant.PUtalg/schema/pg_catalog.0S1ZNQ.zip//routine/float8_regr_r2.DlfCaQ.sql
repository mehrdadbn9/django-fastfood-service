create function float8_regr_r2(double precision[]) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$float8_regr_r2$$;

comment on function float8_regr_r2(double precision[]) is 'aggregate final function';

alter function float8_regr_r2(double precision[]) owner to postgres;

