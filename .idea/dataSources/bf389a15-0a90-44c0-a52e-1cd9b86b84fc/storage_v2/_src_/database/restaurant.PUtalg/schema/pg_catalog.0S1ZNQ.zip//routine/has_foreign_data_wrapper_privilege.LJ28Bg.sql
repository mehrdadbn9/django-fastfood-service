create function has_foreign_data_wrapper_privilege(name, text, text) returns boolean
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$has_foreign_data_wrapper_privilege_name_name$$;

comment on function has_foreign_data_wrapper_privilege(text, text, text) is 'current user privilege on foreign data wrapper by foreign data wrapper name';

alter function has_foreign_data_wrapper_privilege(text, text, text) owner to postgres;

