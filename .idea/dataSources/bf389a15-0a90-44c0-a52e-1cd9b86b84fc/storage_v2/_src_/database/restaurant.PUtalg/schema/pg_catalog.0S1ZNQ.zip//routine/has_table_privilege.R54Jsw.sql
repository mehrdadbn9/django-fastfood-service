create function has_table_privilege(name, text, text) returns boolean
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$has_table_privilege_name_name$$;

comment on function has_table_privilege(text, text, text) is 'current user privilege on relation by rel name';

alter function has_table_privilege(text, text, text) owner to postgres;

