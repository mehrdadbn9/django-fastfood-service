create function hash_numeric_extended(numeric, bigint) returns bigint
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$hash_numeric_extended$$;

comment on function hash_numeric_extended(numeric, bigint) is 'hash';

alter function hash_numeric_extended(numeric, bigint) owner to postgres;

