create function hashcharextended("char", bigint) returns bigint
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$hashcharextended$$;

comment on function hashcharextended("char", bigint) is 'hash';

alter function hashcharextended("char", bigint) owner to postgres;

