create function hashmacaddr8extended(macaddr8, bigint) returns bigint
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$hashmacaddr8extended$$;

comment on function hashmacaddr8extended(macaddr8, bigint) is 'hash';

alter function hashmacaddr8extended(macaddr8, bigint) owner to postgres;

