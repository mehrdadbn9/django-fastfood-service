create function inet_gist_consistent(internal, inet, smallint, oid, internal) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$inet_gist_consistent$$;

comment on function inet_gist_consistent(internal, inet, smallint, oid, internal) is 'GiST support';

alter function inet_gist_consistent(internal, inet, smallint, oid, internal) owner to postgres;

