create function int2abs(smallint) returns smallint
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$int2abs$$;

comment on function int2abs(smallint) is 'implementation of @ operator';

alter function int2abs(smallint) owner to postgres;

