create function int2int4_sum(bigint[]) returns bigint
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$int2int4_sum$$;

comment on function int2int4_sum(bigint[]) is 'aggregate final function';

alter function int2int4_sum(bigint[]) owner to postgres;

