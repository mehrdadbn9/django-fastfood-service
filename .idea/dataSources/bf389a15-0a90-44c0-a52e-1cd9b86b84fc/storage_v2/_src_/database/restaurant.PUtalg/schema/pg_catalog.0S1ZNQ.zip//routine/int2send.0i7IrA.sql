create function int2send(smallint) returns bytea
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$int2send$$;

comment on function int2send(smallint) is 'I/O';

alter function int2send(smallint) owner to postgres;

