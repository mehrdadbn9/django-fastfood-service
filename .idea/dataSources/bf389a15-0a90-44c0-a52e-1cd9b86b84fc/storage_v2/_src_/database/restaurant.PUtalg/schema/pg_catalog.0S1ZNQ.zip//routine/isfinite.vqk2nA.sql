create function isfinite(date) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$date_finite$$;

comment on function isfinite(timestamp) is 'finite timestamp?';

alter function isfinite(timestamp) owner to postgres;

