create function lo_creat(integer) returns oid
    strict
    cost 1
    language internal
as
$$be_lo_creat$$;

comment on function lo_creat(integer) is 'large object create';

alter function lo_creat(integer) owner to postgres;

