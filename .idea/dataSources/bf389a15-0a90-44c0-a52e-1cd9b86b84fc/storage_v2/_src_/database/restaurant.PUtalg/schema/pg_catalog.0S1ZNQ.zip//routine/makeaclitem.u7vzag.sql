create function makeaclitem(oid, oid, text, boolean) returns aclitem
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$makeaclitem$$;

comment on function makeaclitem(oid, oid, text, boolean) is 'make ACL item';

alter function makeaclitem(oid, oid, text, boolean) owner to postgres;

