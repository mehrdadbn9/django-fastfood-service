create function money(bigint) returns money
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$int8_cash$$;

comment on function money(bigint) is 'convert int8 to money';

alter function money(bigint) owner to postgres;

