create function mul_d_interval(double precision, interval) returns interval
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$mul_d_interval$$;

comment on function mul_d_interval(double precision, interval) is 'implementation of * operator';

alter function mul_d_interval(double precision, interval) owner to postgres;

