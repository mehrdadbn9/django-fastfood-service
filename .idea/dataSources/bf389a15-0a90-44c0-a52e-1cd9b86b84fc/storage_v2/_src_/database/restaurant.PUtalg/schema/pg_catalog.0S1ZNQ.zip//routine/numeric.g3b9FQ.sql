create function numeric(money) returns numeric
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$cash_numeric$$;

comment on function numeric(jsonb, int4) is 'convert jsonb to numeric';

alter function numeric(jsonb, int4) owner to postgres;

