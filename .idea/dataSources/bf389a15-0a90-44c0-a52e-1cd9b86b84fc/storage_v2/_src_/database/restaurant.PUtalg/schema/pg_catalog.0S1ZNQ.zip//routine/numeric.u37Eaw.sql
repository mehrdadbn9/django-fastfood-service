create function numeric(money) returns numeric
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$cash_numeric$$;

comment on function numeric(numeric, integer) is 'adjust numeric to typmod precision/scale';

alter function numeric(numeric, integer) owner to postgres;

