create function overlay(bytea, bytea, integer, integer) returns bytea
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$byteaoverlay$$;

comment on function overlay(bit, bit, integer, integer) is 'substitute portion of bitstring';

alter function overlay(bit, bit, integer, integer) owner to postgres;

