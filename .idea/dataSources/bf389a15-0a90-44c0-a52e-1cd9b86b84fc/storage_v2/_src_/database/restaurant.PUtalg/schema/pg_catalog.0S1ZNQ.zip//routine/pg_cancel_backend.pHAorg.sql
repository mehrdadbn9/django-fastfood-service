create function pg_cancel_backend(integer) returns boolean
    strict
    parallel safe
    cost 1
    language internal
as
$$pg_cancel_backend$$;

comment on function pg_cancel_backend(integer) is 'cancel a server process'' current query';

alter function pg_cancel_backend(integer) owner to postgres;

