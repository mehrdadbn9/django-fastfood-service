create function pg_column_compression("any") returns text
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$pg_column_compression$$;

comment on function pg_column_compression("any") is 'compression method for the compressed datum';

alter function pg_column_compression("any") owner to postgres;

