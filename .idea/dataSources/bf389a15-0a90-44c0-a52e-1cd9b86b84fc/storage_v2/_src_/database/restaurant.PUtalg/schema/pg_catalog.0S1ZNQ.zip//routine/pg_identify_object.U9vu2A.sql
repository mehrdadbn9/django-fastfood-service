create function pg_identify_object(classid oid, objid oid, objsubid integer, OUT type text, OUT schema text, OUT name text, OUT identity text) returns record
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$pg_identify_object$$;

comment on function pg_identify_object(oid, oid, integer, out text, out text, out text, out text) is 'get machine-parseable identification of SQL object';

alter function pg_identify_object(oid, oid, integer, out text, out text, out text, out text) owner to postgres;

