create function pg_stat_get_backend_client_addr(integer) returns inet
    stable
    strict
    parallel restricted
    cost 1
    language internal
as
$$pg_stat_get_backend_client_addr$$;

comment on function pg_stat_get_backend_client_addr(integer) is 'statistics: address of client connected to backend';

alter function pg_stat_get_backend_client_addr(integer) owner to postgres;

