create function pg_stat_get_backend_start(integer) returns timestamp with time zone
    stable
    strict
    parallel restricted
    cost 1
    language internal
as
$$pg_stat_get_backend_start$$;

comment on function pg_stat_get_backend_start(integer) is 'statistics: start time for current backend session';

alter function pg_stat_get_backend_start(integer) owner to postgres;

