create function pg_stat_get_backend_userid(integer) returns oid
    stable
    strict
    parallel restricted
    cost 1
    language internal
as
$$pg_stat_get_backend_userid$$;

comment on function pg_stat_get_backend_userid(integer) is 'statistics: user ID of backend';

alter function pg_stat_get_backend_userid(integer) owner to postgres;

