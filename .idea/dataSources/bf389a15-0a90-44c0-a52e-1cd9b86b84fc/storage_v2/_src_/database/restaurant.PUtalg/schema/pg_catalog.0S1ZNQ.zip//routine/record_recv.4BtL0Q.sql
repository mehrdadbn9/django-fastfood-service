create function record_recv(internal, oid, integer) returns record
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$record_recv$$;

comment on function record_recv(internal, oid, integer) is 'I/O';

alter function record_recv(internal, oid, integer) owner to postgres;

