create function regexeqsel(internal, oid, internal, integer) returns double precision
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$regexeqsel$$;

comment on function regexeqsel(internal, oid, internal, integer) is 'restriction selectivity of regex match';

alter function regexeqsel(internal, oid, internal, integer) owner to postgres;

