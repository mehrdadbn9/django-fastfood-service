create function scalargesel(internal, oid, internal, integer) returns double precision
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$scalargesel$$;

comment on function scalargesel(internal, oid, internal, integer) is 'restriction selectivity of >= and related operators on scalar datatypes';

alter function scalargesel(internal, oid, internal, integer) owner to postgres;

