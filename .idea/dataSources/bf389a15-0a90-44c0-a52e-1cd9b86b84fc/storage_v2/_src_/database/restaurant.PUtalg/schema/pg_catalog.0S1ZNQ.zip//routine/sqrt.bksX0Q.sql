create function sqrt(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dsqrt$$;

comment on function sqrt(double precision) is 'square root';

alter function sqrt(double precision) owner to postgres;

