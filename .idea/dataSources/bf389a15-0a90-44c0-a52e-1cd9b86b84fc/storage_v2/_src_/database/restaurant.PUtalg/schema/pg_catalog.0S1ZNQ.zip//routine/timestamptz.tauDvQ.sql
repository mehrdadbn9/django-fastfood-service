create function timestamptz(date) returns timestamp with time zone
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$date_timestamptz$$;

comment on function timestamptz(date, time with time zone) is 'convert date and time with time zone to timestamp with time zone';

alter function timestamptz(date, time with time zone) owner to postgres;

