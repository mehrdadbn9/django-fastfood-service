create function timestamptz_cmp_date(timestamp with time zone, date) returns integer
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$timestamptz_cmp_date$$;

comment on function timestamptz_cmp_date(timestamp with time zone, date) is 'less-equal-greater';

alter function timestamptz_cmp_date(timestamp with time zone, date) owner to postgres;

