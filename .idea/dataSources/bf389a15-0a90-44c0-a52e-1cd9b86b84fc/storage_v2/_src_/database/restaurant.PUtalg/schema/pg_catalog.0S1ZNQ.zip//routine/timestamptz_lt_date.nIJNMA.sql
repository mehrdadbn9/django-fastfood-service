create function timestamptz_lt_date(timestamp with time zone, date) returns boolean
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$timestamptz_lt_date$$;

comment on function timestamptz_lt_date(timestamp with time zone, date) is 'implementation of < operator';

alter function timestamptz_lt_date(timestamp with time zone, date) owner to postgres;

