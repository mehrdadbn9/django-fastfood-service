create function timestamptztypmodin(cstring[]) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$timestamptztypmodin$$;

comment on function timestamptztypmodin(cstring[]) is 'I/O typmod';

alter function timestamptztypmodin(cstring[]) owner to postgres;

