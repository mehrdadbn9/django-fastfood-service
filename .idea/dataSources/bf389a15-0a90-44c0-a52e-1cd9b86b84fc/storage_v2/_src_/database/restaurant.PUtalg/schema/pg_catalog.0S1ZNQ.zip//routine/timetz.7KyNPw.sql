create function timetz(time without time zone) returns time with time zone
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$time_timetz$$;

comment on function timetz(time with time zone, integer) is 'adjust time with time zone precision';

alter function timetz(time with time zone, integer) owner to postgres;

