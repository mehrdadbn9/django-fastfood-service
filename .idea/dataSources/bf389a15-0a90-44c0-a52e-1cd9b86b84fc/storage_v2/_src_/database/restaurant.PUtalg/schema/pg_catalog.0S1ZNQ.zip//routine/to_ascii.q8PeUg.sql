create function to_ascii(text) returns text
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$to_ascii_default$$;

comment on function to_ascii(text, integer) is 'encode text from encoding to ASCII text';

alter function to_ascii(text, integer) owner to postgres;

