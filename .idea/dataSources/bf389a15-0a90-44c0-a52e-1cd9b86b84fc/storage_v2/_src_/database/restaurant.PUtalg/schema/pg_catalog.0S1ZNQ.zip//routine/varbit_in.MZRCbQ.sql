create function varbit_in(cstring, oid, integer) returns bit varying
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$varbit_in$$;

comment on function varbit_in(cstring, oid, integer) is 'I/O';

alter function varbit_in(cstring, oid, integer) owner to postgres;

