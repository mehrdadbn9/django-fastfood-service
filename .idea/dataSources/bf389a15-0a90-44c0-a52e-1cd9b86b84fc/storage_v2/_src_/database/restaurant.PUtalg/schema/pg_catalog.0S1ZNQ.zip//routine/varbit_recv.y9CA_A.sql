create function varbit_recv(internal, oid, integer) returns bit varying
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$varbit_recv$$;

comment on function varbit_recv(internal, oid, integer) is 'I/O';

alter function varbit_recv(internal, oid, integer) owner to postgres;

