create function varchar(name) returns character varying
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$name_text$$;

comment on function varchar(varchar, integer, boolean) is 'adjust varchar() to typmod length';

alter function varchar(varchar, integer, boolean) owner to postgres;

