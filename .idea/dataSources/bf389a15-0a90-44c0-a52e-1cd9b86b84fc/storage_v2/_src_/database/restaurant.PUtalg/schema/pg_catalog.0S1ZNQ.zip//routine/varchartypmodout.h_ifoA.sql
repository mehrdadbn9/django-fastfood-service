create function varchartypmodout(integer) returns cstring
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$varchartypmodout$$;

comment on function varchartypmodout(integer) is 'I/O typmod';

alter function varchartypmodout(integer) owner to postgres;

